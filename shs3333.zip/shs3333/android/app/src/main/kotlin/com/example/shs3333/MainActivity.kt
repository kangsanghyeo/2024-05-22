package com.example.shs3333

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
